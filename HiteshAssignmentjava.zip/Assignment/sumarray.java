public class sumarray{
	public static void main(String[]args)
	{
		int sum=0;
		
		int n=5;
		int arr[]={5,9,7,3,4};
		
		
		for(int i:arr)
		{
			sum=sum+i;
		}
		System.out.println("Sum of array is :"+sum);

	}









}
